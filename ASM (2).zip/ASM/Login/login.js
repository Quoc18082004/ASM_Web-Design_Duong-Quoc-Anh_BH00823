
 const loginForm = document.querySelector('.login-input');

 loginForm.addEventListener('submit', function (event) {

   event.preventDefault();

   const email = loginForm.querySelector('input[name="Email"]').value;
   const password = loginForm.querySelector('input[name="Password"]').value;

   if (!email || !password) {
        alert('Please fill in all the required information!');
        return;
   }

   const userData = localStorage.getItem(email);

   if (!userData) {
        alert('Email does not exist!');
        return;
   }

   const user = JSON.parse(userData);

   if (user.password === password) {
        alert(`Welcome ${user.name}! Login successful.`);
 
        window.location.href = '/Home/Home.html';
   } else {
        alert('Incorrect password!');
   }
 });