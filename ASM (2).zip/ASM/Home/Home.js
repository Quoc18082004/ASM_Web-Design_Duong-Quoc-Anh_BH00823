let cart = JSON.parse(localStorage.getItem('cart')) || []; // Lấy giỏ hàng từ localStorage hoặc tạo giỏ hàng mới
const cartModal = document.getElementById('cartModal');
const cartItemsContainer = document.getElementById('cartItems');
const cartIcon = document.querySelector('.fa-cart-shopping'); // Icon giỏ hàng

// Hiển thị modal
function showModal() {
    cartModal.style.display = 'flex';
    updateCartDisplay();
}

// Đóng modal
function closeModal() {
    cartModal.style.display = 'none';
}

// Thêm sự kiện click cho biểu tượng giỏ hàng
cartIcon.addEventListener('click', showModal);

// Thêm sản phẩm vào giỏ hàng
function addToCart() {
    const productName = document.querySelector('.details h1').innerText;
    const productPrice = parseFloat(document.querySelector('.details .price').innerText.replace('$', ''));
    const quantity = parseInt(document.getElementById('quantity').value, 10);
    const productImage = document.querySelector('.image img').src;

    // Kiểm tra tính hợp lệ của giá và số lượng
    if (isNaN(productPrice) || productPrice <= 0) {
        alert('Invalid product price.');
        return;
    }

    if (isNaN(quantity) || quantity <= 0) {
        alert('Invalid quantity.');
        return;
    }

    // Kiểm tra sản phẩm đã tồn tại trong giỏ hàng
    const existingProduct = cart.find(item => item.name === productName);

    if (existingProduct) {
        existingProduct.quantity += quantity; // Cập nhật số lượng
    } else {
        cart.push({ name: productName, price: productPrice, quantity, image: productImage }); // Thêm mới
    }

    saveCartToLocalStorage(); // Lưu giỏ hàng vào localStorage
    updateCartDisplay();
    updateCartIcon();
    showModal();
}

// Cập nhật hiển thị giỏ hàng
function updateCartDisplay() {
    // Đảm bảo tất cả giá trị price trong giỏ hàng là số
    cart = cart.map(item => ({
        ...item,
        price: parseFloat(item.price) // Chuyển price về số
    }));

    cartItemsContainer.innerHTML = ''; // Xóa nội dung cũ

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>No items found.</p>';
        return;
    }

    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity; // Tính tổng giá trị

        const itemHTML = `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <p><strong>${item.name}</strong></p>
                    <p>$${item.price.toFixed(2)} USD</p>
                    <div class="quantity-control">
                        <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity(${index}, this.value)">
                    </div>
                    <a href="#" class="remove-item" onclick="removeItem(${index})">Remove</a>
                </div>
            </div>
        `;
        cartItemsContainer.innerHTML += itemHTML;
    });

    // Thêm tổng cộng
    cartItemsContainer.innerHTML += `
        <div class="cart-total">
            <p><strong>Subtotal:</strong> $${total.toFixed(2)} USD</p>
        </div>
    `;
}

// Cập nhật biểu tượng giỏ hàng
function updateCartIcon() {
    const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    let badge = cartIcon.querySelector('.cart-badge');

    if (cartCount > 0) {
        if (!badge) {
            badge = document.createElement('span');
            badge.classList.add('cart-badge');
            cartIcon.appendChild(badge);
        }
        badge.innerText = cartCount;
    } else {
        if (badge) badge.remove();
    }
}

// Xóa một sản phẩm khỏi giỏ hàng
function removeItem(index) {
    cart.splice(index, 1); // Xóa sản phẩm
    saveCartToLocalStorage(); // Lưu giỏ hàng vào localStorage
    updateCartDisplay();
    updateCartIcon();
}

// Thay đổi số lượng sản phẩm
function updateQuantity(index, newQuantity) {
    const quantity = parseInt(newQuantity, 10);

    if (isNaN(quantity) || quantity <= 0) {
        removeItem(index); // Xóa sản phẩm nếu số lượng không hợp lệ
    } else {
        cart[index].quantity = quantity;
        saveCartToLocalStorage(); // Lưu giỏ hàng vào localStorage
        updateCartDisplay();
        updateCartIcon();
    }
}

// Lưu giỏ hàng vào localStorage
function saveCartToLocalStorage() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Khi trang được tải lại, giỏ hàng sẽ được lấy từ localStorage và hiển thị
document.addEventListener('DOMContentLoaded', () => {
    // Đảm bảo tất cả dữ liệu trong giỏ hàng là hợp lệ
    cart = cart.map(item => ({
        ...item,
        price: parseFloat(item.price),
        quantity: parseInt(item.quantity, 10)
    })).filter(item => !isNaN(item.price) && item.price > 0 && !isNaN(item.quantity) && item.quantity > 0);

    updateCartDisplay();
    updateCartIcon();
});

const price = document.getElementById('price');

console.log(price.textContent);
