 const form = document.querySelector('.register-item');
  
form.addEventListener('submit', function (event) {

   event.preventDefault();
   
   const email = form.querySelector('input[name="email"]').value;
   const name = form.querySelector('input[name="Name"]').value;
   const password = form.querySelector('input[name="password"]').value;

   if (!email || !name || !password) {
    alert('Please fill in all the information!');
    return;
}

const user = {
    email: email,
    name: name,
    password: password
};

localStorage.setItem(email, JSON.stringify(user));

alert('Registration successful!');
window.location.href = '/Login/login.html';
});
